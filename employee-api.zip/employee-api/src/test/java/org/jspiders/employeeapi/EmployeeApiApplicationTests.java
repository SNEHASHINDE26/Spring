package org.jspiders.employeeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
