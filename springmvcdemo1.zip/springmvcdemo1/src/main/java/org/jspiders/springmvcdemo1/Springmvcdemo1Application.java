package org.jspiders.springmvcdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springmvcdemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springmvcdemo1Application.class, args);
	}

}
