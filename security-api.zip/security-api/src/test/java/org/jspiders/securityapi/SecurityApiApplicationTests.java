package org.jspiders.securityapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
