package org.jspiders.springrestapi1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springrestapi1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springrestapi1Application.class, args);
	}

}
